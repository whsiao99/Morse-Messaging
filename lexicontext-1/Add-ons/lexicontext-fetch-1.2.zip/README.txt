Welcome to Lexicontext Fetch

This README contains:

1. Introduction
2. Integration Information

============
Introduction
============

Lexicontext Fetch takes care of downloading, unzipping and installing the dictionary data files bundle *after* 
the application was already installed by the user. 
Lexicontext Fetch is useful when you don't want to bundle Lexicontext's data together with your app as a resource 
bundle (you may want to reduce the app's original archive size or maybe you want to charge for the dictionary, 
etc).

The distribution of Lexicontext Fetch contains the source code, so that you can further adapt it to your needs.

This archive contains the following files:

- README.txt : this text file 
- LICENSE.txt : contains licensing info
- LexicontextFetch.h : the header file to import from your code
- LexicontextFetch.m & the ZipArchive folder : the library's source code. Feel free to further adapt it to your needs :)
- libLexicontextFetch.a : the precompiled library containing the pronunciation functionality

========================================
Integration (with libLexicontextFetch.a)
========================================

To add Lexicontext Fetch to your Lexicontext-enabled iOS application:

1. Extract the downloaded lexicontext-fetch-1.1.zip on your Mac.

2. Open your app's XCode project and from the menu select Project->Add to Project... (or use the shortcut ⌥+⌘+A). 
   
   Browse to the folder where you extracted the lexicontext pronounce zip file, select the files 
   LexicontextFetch.h and libLexicontextFetch.a and click the "Add" button. 

   In the next dialog, make sure that the option "Copy items into group's folder (if needed)" is checked and 
   click the "Add" button. 

   The files will be copied into your XCode's project and after a few seconds they will show up in your 
   project tree.

3. Drag the header file to your Classes Group and the library file to your Frameworks Group.
   This step is optional but it will help you keep your project tidy. 

4. XCode 3.x: In XCode's project tree, expand the "Targets" group and then expand your app target entry. 
   In the project tree, drag the libLexicontextFetch.a entry into your target's "Link Binary With Libraries" group
   (XCode 4 takes care of this automatically for you).

5. Add the libz.dylib library to the list of libraries your app links to (add it just like you add other 
   existing frameworks to your app).

6. Using Lexicontext Fetch in your code:

   a. To start the download add the following code somewhere in your "Downloader" class =>
         ...
         LexicontextFetch *fetcher = [[[LexicontextFetch alloc] init] autorelease];  
         NSString *docsDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
         [fetcher fetchZippedBundleWithUrl:@"http://mysite.com/LexicontextAssets.bundle.zip" targetFolder:docsDir fetchDelagate:self];
         ...
      In this example the data bundle is installed into the app's docs directory. 
      Note also that Lexicontext Fetch assumes that you've zipped the LexicontextAssets.bundle directory and the URL points to 
      the zipped bundle.

   b. If you want to get notifications about the download & unzip progress, one of your classes needs to adopt the 
      LexicontextFetchDelegate protocol. Assuming the name of this class is "Downloader", its header would 
      look as follows =>
         ...
         #import "LexicontextFetch.h" 
         ...
         @interface Downloader : NSObject <LexicontextFetchDelegate> {
         ...

   c. Implement the methods you need from the LexicontextFetchDelegate protocol.
      For example, if you want to show a progress bar during the download you should implement the lexicontextDidReceiveBytes 
      method =>
         ...
         - (void)lexicontextDidReceiveBytes:(NSInteger)bytesReceived totalBytes:(NSInteger)totalBytes {
           NSLog(@"bytes downloaded so far: %d out of %d", bytesReceived, totalBytes);    
         }
         ...
         
      You should also implement at least the lexicontextUnzipDidSucceed method which notifies you that the download and unzip 
      process has finished successfully =>
         ...
         - (void)lexicontextUnzipDidSucceed:(NSString *)targetFolderPath {
           NSString *bundlePath = [targetFolderPath stringByAppendingPathComponent:@"LexicontextAssets.bundle"];
           if ([[NSFileManager defaultManager] fileExistsAtPath:bundlePath]) {
             Lexicontext *dictionary = [Lexicontext sharedDictionaryWithBundlePath:bundlePath];
           }
           else {
             NSLog(@"Something bad happened... Maybe the bundle was not zipped properly ???");
           }
         }
         ...

      Obviously, in subsequent initialization of the dictionary you wouldn't have to download the dictionary again and you 
      can simply construct it by calling [Lexicontext sharedDictionaryWithBundlePath:bundlePath] where bundlePath is the path
      where the bundle was saved by the Fetch process.

==================================================================================================

Please let us know if you have any questions. If you need any help, just email ori@lexicontext.com

Cheers,
The Lexicontext Team
http://www.lexicontext.com
ori@lexicontext.com
