/*
 * Copyright 2011 Rubnatak Holding
 *
 * Licensed under the Lexicontext terms of use (the "Terms of Use");
 * you may not use this file except in compliance with the Terms of Use.
 * You may obtain a copy of the Terms of Use at
 * 
 *    http://www.lexicontext.com/terms.html
 *
 * as well as the LICENSE.txt file that is provided together with this 
 * software package.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Terms of Use is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Terms of Use for the specific language governing permissions and
 * limitations under the Terms of Use.
 */

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


/**
 * The Lexicontext Fetch delegate gets notified about the progress of the download
 * and unzip process.
 */

@protocol LexicontextFetchDelegate <NSObject>

@optional

/**
 * Called during the fetch process and notifies the caller of the download progress 
 */
- (void)lexicontextDidReceiveBytes:(NSInteger)bytesReceived totalBytes:(NSInteger)totalBytes;

/**
 * Called when download of the zipped data bundle is complete
 */
- (void)lexicontextDownloadDidSucceed:(NSString *)downloadPath;

/**
 * Called when fetch of the zipped data bundle failed
 */
- (void)lexicontextDownloadDidFailWithError:(NSError *)error;

/**
 * Called when the unziping of the data bundle finished successfully
 */
- (void)lexicontextUnzipDidSucceed:(NSString *)targetFolderPath;

/**
 * Called when the unziping of the data bundle failed
 */
- (void)lexicontextUnzipDidFailWithError:(NSError *)error;

@end


/**
 * Lexicontext Fetch takes care of downloading, unzipping and installing the dictionary
 * data files bundle *after* the application was already installed by the user.
 * The data files bundle is assumed to be packaged as a zip file.
 */
@interface LexicontextFetch : NSObject {    
    
    @private
    NSString *targetPath;
    NSString *downloadPath;
    NSOutputStream *downloadStream;
    id<LexicontextFetchDelegate> fetchDelegate;
    NSNumber *contentLength;
    NSInteger totalWritten;    
}


/**
 * This method asynchronously downloads & extracts the zipped data-files bundle 
 *
 * @param url the zipped data-bundle URL 
 * @param targetFolder the folder where the downloaded zip should be extracted
 * @param fetchDelagate the delegate that should be notified about the fetch events
 */
- (void)fetchZippedBundleWithUrl:(NSString *)url 
                    targetFolder:(NSString *)targetFolderPath 
                   fetchDelagate:(id<LexicontextFetchDelegate>)delegate;


@end

