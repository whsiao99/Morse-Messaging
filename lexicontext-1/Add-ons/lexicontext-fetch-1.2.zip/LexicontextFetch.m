
#import "LexicontextFetch.h"
#import "ZipArchive.h"

/////////////////////////////////////////////////////////////////
// Error Constants 
NSString * const kLexicontextErrorDomain = @"Lexicontext";
typedef enum {
	kLexicontextErrorNoSpace = 1,
	kLexicontextErrorHttpError,
	kLexicontextErrorNoContentType,
	kLexicontextErrorUnsupportedContentType,
    kLexicontextErrorUnzipFailed
} kLexicontextFetchError;

/////////////////////////////////////////////////////////////////
// An HTTPExtensions category for parsing the content type header

@interface NSString (HTTPExtensions)

- (BOOL)isHTTPContentType:(NSString *)prefixStr;

@end

@implementation NSString (HTTPExtensions)

- (BOOL)isHTTPContentType:(NSString *)prefixStr {
    BOOL result = NO;
    NSRange foundRange = [self rangeOfString:prefixStr options:NSAnchoredSearch | NSCaseInsensitiveSearch];
    if (foundRange.location != NSNotFound) {
        assert(foundRange.location == 0);            // because it's anchored
        if (foundRange.length == self.length) {
            result = YES;
        } else {
            unichar nextChar;            
            nextChar = [self characterAtIndex:foundRange.length];
            result = nextChar <= 32 || nextChar >= 127 || (strchr("()<>@,;:\\<>/[]?={}", nextChar) != NULL);
        }
        
        /*
         From RFC 2616:         
             token          = 1*<any CHAR except CTLs or separators>
             separators     = "(" | ")" | "<" | ">" | "@" | "," | ";" | ":" | "\" | <"> | "/" | "[" | "]" | "?" | 
                              "=" | "{" | "}" | SP | HT         
             media-type     = type "/" subtype *( ";" parameter )
             type           = token
             subtype        = token
        */
    }
    return result;
}

@end

/////////////////////////////////////////////////////////////////
@implementation LexicontextFetch

// Get path for a temp file with the provided prefix
- (NSString *)pathForTempFileWithPrefix:(NSString *)prefix {
    NSString *  result;
    CFUUIDRef   uuid;
    CFStringRef uuidStr;
    
    uuid = CFUUIDCreate(NULL);
    assert(uuid != NULL);
    
    uuidStr = CFUUIDCreateString(NULL, uuid);
    assert(uuidStr != NULL);
    
    result = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"%@-%@", prefix, uuidStr]];
    assert(result != nil);
    
    CFRelease(uuidStr);
    CFRelease(uuid);
    
    return result;
}

// Contruct an NSError 
- (NSError *)getError:(NSInteger)code description:(NSString *)description {
    NSError *error = [[NSError alloc] initWithDomain:kLexicontextErrorDomain 
                                                code:kLexicontextErrorHttpError 
                                            userInfo:[NSDictionary dictionaryWithObject:description forKey:@"Details"]];
    [error autorelease]; 
    return error;
}

// Unzip file into a target parent folder
- (BOOL) unzip:(NSString *)zipPath target:(NSString *)target{
	ZipArchive* archive = [[ZipArchive alloc] init];
	if (![archive UnzipOpenFile:zipPath]) {
        return NO;                
    }
    if (![archive UnzipFileTo:target overWrite:YES]) {
        return NO;        
    }
    if (![archive UnzipCloseFile]) {
        return NO;        
    }
    [archive release];
    return YES;
}

// Shut down the connection, notify delegate 
- (void) stopReceiveWithConnection:(NSURLConnection *)connection error:(NSError *)error {    
    if (connection != nil) {
        [connection cancel];
    }

    if (downloadStream != nil) {
        [downloadStream close];
    }
    
    if (error == nil) {
        if ([fetchDelegate respondsToSelector:@selector(lexicontextDownloadDidSucceed:)]) {
            [fetchDelegate lexicontextDownloadDidSucceed:downloadPath];            
        }
        BOOL unzipped = [self unzip:downloadPath target:targetPath];
        if (!unzipped) {
            // TODO: remove target folder (after zip failure)
                        
            if ([fetchDelegate respondsToSelector:@selector(lexicontextUnzipDidFailWithError:)]) {
                [fetchDelegate lexicontextUnzipDidFailWithError:[self getError:kLexicontextErrorUnzipFailed description:@"Failed to unzip data bundle"]];            
            }
        }
        else {
            if ([fetchDelegate respondsToSelector:@selector(lexicontextUnzipDidSucceed:)]) {
                [fetchDelegate lexicontextUnzipDidSucceed:targetPath];            
            }
        }
        
    }
    else {
        if ([fetchDelegate respondsToSelector:@selector(lexicontextDownloadDidFailWithError:)]) {
            [fetchDelegate lexicontextDownloadDidFailWithError:error];            
        }
    }        
    
    // Cleanup downloaded zip
    BOOL downloadFileRemoved = [[NSFileManager defaultManager] removeItemAtPath:downloadPath error:NULL];
    if (!downloadFileRemoved) {
        NSLog(@"LexicontextFetch: failed to remove temp zip file");
    }

}

// Trigger the async file download
- (void) asyncFileDownloadWithUrl:(NSString *)urlStr delegate:(id<LexicontextFetchDelegate>)delegate {
    NSURL *url = [NSURL URLWithString:urlStr];
    delegate = delegate;
    [delegate retain];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    NSURLConnection *connection = [[[NSURLConnection alloc] initWithRequest:request 
                                                                   delegate:self 
                                                           startImmediately:YES] 
                                   autorelease];
    
    downloadStream = [NSOutputStream outputStreamToFileAtPath:downloadPath append:YES];
    [downloadStream open];
    [downloadStream retain];
    BOOL hasSpace = [downloadStream hasSpaceAvailable];
    if (!hasSpace) {
        [self stopReceiveWithConnection:connection error:[self getError:kLexicontextErrorNoSpace description:@"No space available"]];
    }
}


// A delegate method called by the NSURLConnection when the request/response exchange is complete.  
// We look at the response to check that the HTTP status code is 2xx and that the Content-Type is acceptable.  If these checks 
// fail, we give up on the transfer.
- (void)connection:(NSURLConnection *)theConnection didReceiveResponse:(NSURLResponse *)response {
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
	
    if ((httpResponse.statusCode / 100) != 2) {
        [self stopReceiveWithConnection:theConnection error:[self getError:kLexicontextErrorHttpError description:[NSString stringWithFormat:@"HTTP error %zd", (ssize_t) httpResponse.statusCode]]];
    } else {
        NSString *contentTypeHeader = [httpResponse.allHeaderFields objectForKey:@"Content-Type"];
        NSString *contentLengthString = [httpResponse.allHeaderFields objectForKey:@"Content-Length"];
		if (contentLengthString) {
			contentLength = [NSNumber numberWithInt:[contentLengthString intValue]];
            [contentLength retain];
		}
        if (contentTypeHeader == nil) {
            [self stopReceiveWithConnection:theConnection error:[self getError:kLexicontextErrorNoContentType description:@"No Content-Type!"]];
        } else if ( ! [contentTypeHeader isHTTPContentType:@"application/zip"] ) {
            [self stopReceiveWithConnection:theConnection error:[self getError:kLexicontextErrorUnsupportedContentType description:[NSString stringWithFormat:@"Unsupported Content-Type (%@)", contentTypeHeader]]];
        } 
    }    
}

// A delegate method called by the NSURLConnection as data arrives.  We just write the data to the file.
- (void)connection:(NSURLConnection *)theConnection didReceiveData:(NSData *)data {
    NSUInteger dataLength;
    const uint8_t *dataBytes;
    NSUInteger bytesWritten;
    NSUInteger bytesWrittenSoFar;
    
    dataLength = [data length];
    dataBytes  = [data bytes];
        
    bytesWrittenSoFar = 0;
    do {
        bytesWritten = [downloadStream write:&dataBytes[bytesWrittenSoFar] maxLength:dataLength - bytesWrittenSoFar];
        if (bytesWritten == -1) {
            NSError *error = [downloadStream streamError];            
            [self stopReceiveWithConnection:theConnection error:error];
            break;
        } else {
            bytesWrittenSoFar += bytesWritten;
        }
    } while (bytesWrittenSoFar != dataLength);
    
	totalWritten += bytesWrittenSoFar;    	
    if (contentLength) {
        NSInteger length = [contentLength intValue];
        if ([fetchDelegate respondsToSelector:@selector(lexicontextDidReceiveBytes:totalBytes:)]) {
            [fetchDelegate lexicontextDidReceiveBytes:totalWritten totalBytes:length];            
        }
    }	
}

// A delegate method called by the NSURLConnection if the connection fails. We shut down the connection and abort.  
- (void)connection:(NSURLConnection *)theConnection didFailWithError:(NSError *)error {    
    [self stopReceiveWithConnection:theConnection error:error];
}

// A delegate method called by the NSURLConnection when the connection has been done successfully.  
// We shut down the connection with no errors
- (void)connectionDidFinishLoading:(NSURLConnection *)theConnection {    
    [self stopReceiveWithConnection:theConnection error:nil];
}

// Asynchronously downloads & extracts the zipped data-files bundle 
- (void)fetchZippedBundleWithUrl:(NSString *)url 
                    targetFolder:(NSString *)targetFolderPath 
                   fetchDelagate:(id<LexicontextFetchDelegate>)delegate {
    
    targetPath = targetFolderPath;
    [targetPath retain];
    
    downloadPath = [self pathForTempFileWithPrefix:@"LexicontextFetch"];
    [downloadPath retain];    

    fetchDelegate = delegate;
    [fetchDelegate retain];
    
    [self asyncFileDownloadWithUrl:url delegate:delegate];
}

- (void)dealloc {
    [targetPath release];
    [downloadPath release];
    [downloadStream release];
    [fetchDelegate release];
    [contentLength release];
    [super dealloc];
}             
             
@end
