Welcome to Lexicontext Pronounce

This README contains:

1. Introduction
2. Integration Information

============
Introduction
============

The Lexicontext Pronounce category adds to Lexicontext the functionality of audio pronunciation for a given 
dictionary word. The word's pronunciation is looked up using a free service provided by www.merriam-webster.com.

This archive contains the following files:

- README.txt : this text file 
- LICENSE.txt : contains licensing info
- Lexicontext+Pronounce.h : the header file to import from your code (instead of the original Lexicontext.h) which 
  adds the Pronounce category to Lexicontext.
- Lexicontext+Pronounce.m : the library's source code. Feel free to further adapt it to your needs :)
- libLexicontextPronounce.a : the precompiled library containing the pronunciation functionality. 

The distribution of Lexicontext Pronounce contains the source code, so that you can further adapt it to your needs.

IMPORTANT: Please review the notes below before using this functionality in your app.

1. Lexicontext is not affiliated in any way with merriam-webster.com. Merriam-webster.com contains 
   copyrighted material, trademarks, and other proprietary information and the word's audio may be 
   subject to copyright restrictions. Before using this category you need to make sure that your app 
   complies with merriam-webster.com's terms of use.

2. the method(s) of this category may not work properly if merriam-webster.com chooses to modify their 
   service's API.

3. the method(s) of this category require that your app has a network connection to merriam-webster.com.

=============================================
Integration (using libLexicontextPronounce.a) 
=============================================

To add Lexicontext Pronounce to your Lexicontext-enabled iOS application:

1. Extract the downloaded lexicontext-pronounce-1.1.zip on your Mac.

2. Open your app's XCode project and from the menu select Project->Add to Project... (or use the shortcut ⌥+⌘+A).
   
   Browse to the folder where you extracted the lexicontext pronounce zip file, select the files 
   Lexicontext+Pronounce.h and libLexicontextPronounce.a and click the "Add" button. 
   
   In the next dialog, make sure that the option "Copy items into group's folder (if needed)" is checked and click 
   the "Add" button. 
   
   The files will be copied into your XCode's project and after a few seconds they will show up in your project tree.

3. Drag the header file to your Classes Group and the library file to your Frameworks Group.
   This step is optional but it will help you keep your project tidy. 

4. XCode 3.x: In XCode's project tree, expand the "Targets" group and then expand your app target entry. In 
   your XCode project tree, drag the libLexicontextPronounce.a entry into your target's "Link Binary With Libraries" group.

5. In your class:
   a. Import Lexicontext with pronounce instead of the usual lexicontext import => #import "Lexicontext+Pronounce.h" 
   b. Obtain a reference to the dictionary => Lexicontext *dictionary = [Lexicontext sharedDictionary];
   c. Fetch & play a word pronunciation => [dictionary pronounce:@"earnest"];

6. Add the iOS SDK AudioToolbox framework to the list of your project's frameworks.

7. OPTIONAL: If you want to get notified when the pronunciation finished:
   a. add a callback method to your class which will be called after the word is pronounced => 
      - (void)pronounceCallback:(NSNumber *)status { ... }
      (You can then use [status boolValue] to check if the pronunciation was successful)
   b. IMPORTANT: Due to a known linker bug you will need to add the following "force load" flag to your "other 
      linker flags" build settings => -force_load libLexicontextPronounce.a
      (see http://developer.apple.com/library/mac/#qa/qa1490/_index.html for more details of this bug)
   c. Fetch & play a word pronunciation => 
      [dictionary pronounce:@"earnest" withTarget:self selector:@selector(pronounceCallback:)];


==================================================================================================

Please let us know if you have any questions. If you need any help, just email ori@lexicontext.com!

Cheers,
The Lexicontext Team
http://www.lexicontext.com
ori@lexicontext.com
